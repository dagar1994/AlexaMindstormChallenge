# -*- coding: utf-8 -*-
"""
2048 Voice Game
"""

from __future__ import print_function
import random
import Constants
import boto3
from boto3.dynamodb.conditions import Key, Attr
import time
import requests
import json


def build_speechlet_response_stop(output, reprompt_text, should_end_session,apiAccessToken,stopUrl):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        },
        'shouldEndSession': should_end_session,
        "directives": [
            {
              "type": "Alexa.Presentation.HTML.Start",
              "startupData": {}, 
              "configuration": {
                "timeoutInSeconds": 1800 
              },
              "headers": {
                "authToken": apiAccessToken 
              },
              "url": stopUrl
            }
            ]
    }

def build_speechlet_response(output, reprompt_text, should_end_session,apiAccessToken):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        },
        'shouldEndSession': should_end_session
    }
    
    
def build_speechlet_response_no_mic(output, reprompt_text, should_end_session,apiAccessToken):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        }
    }
    
def build_speechlet_response_Move_button(direction,endpointId):
    print("Sending the Gadget Event to the WEBAPP")
    return {
        "directives": [{
                      "type":"Alexa.Presentation.HTML.HandleMessage",
                      "message": {
                          "direction" : direction,
                          "type" : "move"
                          
                      },
                      "transformers" : []
                       
                    },
                    {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 90000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND"  
                }
            }
                    
                    ]
        
        }

def build_speechlet_response_Move(output, reprompt_text, should_end_session,apiAccessToken,direction):
    return {
        "directives": [{
                      "type":"Alexa.Presentation.HTML.HandleMessage",
                      "message": {
                          "direction" : direction,
                          "type" : "move"
                          
                      },
                      "transformers" : []
                       
                    }]
        
        }
    


def build_speechlet_response_Move_sound(output, reprompt_text, should_end_session,apiAccessToken,direction):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        }
    }



def build_speechlet_response_Restart(output, reprompt_text, should_end_session,apiAccessToken):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        "directives": [{
                      "type":"Alexa.Presentation.HTML.HandleMessage",
                      "message": {
                          "direction" : "restart",
                          "type" : "move"
                          
                      },
                      "transformers" : []
                       
                    }],
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        }
    }
    
    
def build_speechlet_response_Pause(output, reprompt_text, should_end_session,apiAccessToken):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        "directives": [{
                      "type":"Alexa.Presentation.HTML.HandleMessage",
                      "message": {
                          "direction" : "pause",
                          "type" : "move"
                          
                      },
                      "transformers" : []
                       
                    }],
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        }
    }
    
    
    
def build_speechlet_response_Continue(output, reprompt_text, should_end_session,apiAccessToken):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        "directives": [{
                      "type":"Alexa.Presentation.HTML.HandleMessage",
                      "message": {
                          "direction" : "continue",
                          "type" : "move"
                          
                      },
                      "transformers" : []
                       
                    }],
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        }
    }




def build_speechlet_response_HTML( output, reprompt_text, should_end_session,apiAccessToken,device,endpointId):
    if device == "small" or device == "medium":
        urlToOpen = Constants.gameMainUrlFiveInch
    elif device == "tv":
        urlToOpen = Constants.gameMainUrlFull
    else:
        urlToOpen = Constants.gameMainUrl
    
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        "directives": [
            {
              "type": "Alexa.Presentation.HTML.Start",
              "startupData": {}, 
              "configuration": {
                "timeoutInSeconds": 1800 
              },
              "headers": {
                "authToken": apiAccessToken 
              },
              "url": urlToOpen
            },
            {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 90000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND"  
                }
            }
            
            ],
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': '<speak>' + reprompt_text + '</speak>'
            }
        },
        'shouldEndSession': should_end_session
    }


def build_response(session_attributes, speechlet_response):
    returnAlexaResponse =  {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }
    print(returnAlexaResponse)
    return returnAlexaResponse
    
    
    
def basicInfoToWeb(session):
    userData = getPregameData(session)
    bestScore = userData['bestScore']
    return {
        "directives": [{
                      "type":"Alexa.Presentation.HTML.HandleMessage",
                      "message": {
                          "direction" : "updateHighScore",
                          "highScore" : bestScore
                          
                      },
                      "transformers" : []
                       
                    }]
    }


## ----------------------- Utility Functions ----------------------------


def getUserData(userId,session):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('2048Voice')
    try:
        response = table.get_item(Key={ 'userId': userId })
        userExistance = response['Item']['userExistance']
        userData = response['Item']
    except:
        userData = {
            'userId' : userId,
            'userExistance' : True,
            'numberOfVisits' : 0,
            'numberOfGamesPlayed' : 0,
            'bestScore' : 0
        }
        table.put_item(Item=userData)
    return userData



def getUserId(session):
    userId = session['user']['userId']  # get the userId of the current user
    userId = userId[18:]
    return userId



def getPregameData(session):
    userId = getUserId(session)
    userData = getUserData(userId,session)
    return userData

def updateBestScore(session,bestScore):
    userData = getPregameData(session)
    userData.update({"bestScore" : bestScore})
    updateUserData(userData)
    

def updateUserData(userData):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('2048Voice')
    table.put_item(Item=userData)

def checkState(session,currentStatesToCheck):
    try:
        sessionAttributes = session['attributes']
        currentState = session['attributes']['currentState']
    except:
        return 0
    for currentStateToCheck in currentStatesToCheck:
        if currentState == currentStateToCheck:
            return 1
        else:
            continue
    return 2

def checkDirection(intent):
    try:
        direction = intent['slots']['direction']["resolutions"]["resolutionsPerAuthority"][0]["values"][0]["value"]["name"]
        return direction
    except:
        return "X"


def getAudioForMove(direction):
    if direction.lower() == 'left':
        return Constants.leftAudio
    if direction.lower() == 'right':
        return Constants.rightAudio
    if direction.lower() == 'up':
        return Constants.upAudio
    if direction.lower() == 'down':
        return Constants.downAudio
    

def giveMovementResponse(sessionAttributes,maxTileTillNow,mergedTilesNo,apiAccessToken):
    print("In sound response XXXXXXXXXX")
    direction = sessionAttributes['direction']
    # if mergedTilesNo == 1:
    #     speech_output = Constants.mergeAudioOne
    # elif mergedTilesNo == 2:
    #     speech_output = Constants.mergeAudioOne + Constants.mergeAudioOne
    # elif mergedTilesNo == 3:
    #     speech_output = Constants.mergeAudioOne + Constants.mergeAudioOne + Constants.mergeAudioOne
    speech_output = "<break time='0.5s'/>" 
    reprompt_text = random.choice(Constants.movementReprompt)
    maintainContext = random.choice(Constants.movementMaintainContext)
    should_end_session = False
    return build_response(sessionAttributes, build_speechlet_response_Move_sound(
            speech_output, reprompt_text, should_end_session,apiAccessToken,direction))


def moveIntent(intent,session,apiAccessToken):
    stateCheck = checkState(session,['welcome','gameStarted'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        direction = checkDirection(intent)
        if direction == "X":
            return invalidDirection(session,apiAccessToken)
        direction = direction.lower()
        
        # speech_output = random.choice(Constants.movementMessage).format(direction)
        # reprompt_text = random.choice(Constants.movementReprompt)
        # maintainContext = random.choice(Constants.movementMaintainContext)
        
        
        speech_output = getAudioForMove(direction)
        reprompt_text = random.choice(Constants.movementReprompt)
        maintainContext = random.choice(Constants.movementMaintainContext)
        
        
        should_end_session = False
        sessionAttributes = session["attributes"]
        sessionAttributes.update({'currentState' : 'gameStarted','maintainContextSpeech' : maintainContext,'direction' : direction})
        return build_response(sessionAttributes, build_speechlet_response_Move(
            speech_output, reprompt_text, should_end_session,apiAccessToken,direction))

def restartIntent(intent,session,apiAccessToken):
    stateCheck = checkState(session,['welcome','gameStarted','gameEnded','gamePaused'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        sessionAttributes = session["attributes"]
        speech_output = random.choice(Constants.restartMessage)
        reprompt_text = random.choice(Constants.restartMessageReprompt)
        maintainContext = random.choice(Constants.restartMessageMaintainContext)
        sessionAttributes.update({'currentState' : 'gameStarted','maintainContextSpeech' : maintainContext,'gameWon' : False})
        should_end_session = False
        return build_response(sessionAttributes, build_speechlet_response_Restart(
            speech_output, reprompt_text, should_end_session,apiAccessToken))
            
def pauseIntent(intent,session,apiAccessToken):
    stateCheck = checkState(session,['welcome','gameStarted','gameEnded'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        sessionAttributes = session["attributes"]
        speech_output = random.choice(Constants.pauseMessage)
        reprompt_text = random.choice(Constants.pauseMessageReprompt)
        maintainContext = random.choice(Constants.pauseMessageMaintainContext)
        sessionAttributes.update({'currentState' : 'gamePaused','maintainContextSpeech' : maintainContext,'gameWon' : False})
        should_end_session = False
        return build_response(sessionAttributes, build_speechlet_response_Pause(
            speech_output, reprompt_text, should_end_session,apiAccessToken))
            
def yesIntent(intent,session,apiAccessToken):
    print("Yes Intent Called")
    print("This is the session")
    print(session)
    stateCheck = checkState(session,['gameEnded'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        sessionAttributes = session["attributes"]
        speech_output = random.choice(Constants.restartMessage)
        reprompt_text = random.choice(Constants.restartMessageReprompt)
        maintainContext = random.choice(Constants.restartMessageMaintainContext)
        sessionAttributes.update({'currentState' : 'gameStarted','maintainContextSpeech' : maintainContext,'gameWon' : False})
        should_end_session = False
        return build_response(sessionAttributes, build_speechlet_response_Restart(
            speech_output, reprompt_text, should_end_session,apiAccessToken))

def noIntent(intent,session,apiAccessToken,device):
    if device == "small" or device == "medium":
        stopUrl = Constants.gameStopUrlFiveInch
    elif device == "tv":
        stopUrl = Constants.gameStopUrlFull
    else:
        stopUrl = Constants.gameStopUrl
    stateCheck = checkState(session,['gameEnded'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        sessionAttributes = session["attributes"]
        speech_output = random.choice(Constants.restartNoMessage)
        reprompt_text = random.choice(Constants.restartNoMessageReprompt)
        maintainContext = random.choice(Constants.restartNoMessageMaintainContext)
        sessionAttributes.update({'currentState' : 'gameStarted','maintainContextSpeech' : maintainContext,'gameWon' : False})
        should_end_session = True
        return build_response(sessionAttributes, build_speechlet_response_stop(
            speech_output, reprompt_text, should_end_session,apiAccessToken,stopUrl))


def stopIntent(intent,session,apiAccessToken,device):
    if device == "small" or device == "medium":
        stopUrl = Constants.gameStopUrlFiveInch
    elif device == "tv":
        stopUrl = Constants.gameStopUrlFull
    else:
        stopUrl = Constants.gameStopUrl
    speech_output = random.choice(Constants.stopMessage)
    reprompt_text = random.choice(Constants.stopMessageReprompt)
    maintainContext = random.choice(Constants.stopMessageMaintainContext)
    should_end_session = True
    return build_response({}, build_speechlet_response_stop(
        speech_output, reprompt_text, should_end_session,apiAccessToken,stopUrl))


            
def continueIntent(intent,session,apiAccessToken):
    print("Continue Intent is called")
    print("Tis is the session")
    print(session)
    stateCheck = checkState(session,['gameEnded','gamePaused'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        sessionAttributes = session["attributes"]
        if sessionAttributes['currentState'] == 'gameEnded':
            speech_output = random.choice(Constants.resumeMessage)
            reprompt_text = random.choice(Constants.resumeMessageReprompt)
            maintainContext = random.choice(Constants.resumeMessageMaintinContext)
        else:
            speech_output = random.choice(Constants.continueMessage)
            reprompt_text = random.choice(Constants.continueMessageReprompt)
            maintainContext = random.choice(Constants.continueMessageMaintinContext)
        sessionAttributes.update({'currentState' : 'gameStarted','maintainContextSpeech' : maintainContext})
        should_end_session = False
        return build_response(sessionAttributes, build_speechlet_response_Continue(
            speech_output, reprompt_text, should_end_session,apiAccessToken))
            
            
        

def contextMaintainer(session,apiAccessToken):
    sessionAttributes = session['attributes']
    maintainContextSpeech = sessionAttributes['maintainContextSpeech']
    speech_output = random.choice(Constants.maintainContextPrefix) + maintainContextSpeech
    reprompt_text = maintainContextSpeech
    should_end_session = False
    if sessionAttributes['currentState'] == "gamePaused":
        return build_response(sessionAttributes, build_speechlet_response_no_mic(
            speech_output, reprompt_text, should_end_session, apiAccessToken))
        
    return build_response(sessionAttributes, build_speechlet_response(
        speech_output, reprompt_text, should_end_session, apiAccessToken))
        
        
def fallbackIntent(session,apiAccessToken):
    stateCheck = checkState(session,['gameEnded','welcome','gameStarted'])
    if stateCheck == 0:
        return get_welcome_response(session,apiAccessToken)
    elif stateCheck == 2:
        return contextMaintainer(session,apiAccessToken)
    else:
        sessionAttributes = session['attributes']
        maintainContextSpeech = sessionAttributes['maintainContextSpeech']
        speech_output = random.choice(Constants.maintainContextPrefix) + maintainContextSpeech
        reprompt_text = maintainContextSpeech
        should_end_session = False
        if sessionAttributes['currentState'] == "gamePaused":
            return build_response(sessionAttributes, build_speechlet_response_no_mic(
                speech_output, reprompt_text, should_end_session, apiAccessToken))
        return build_response(sessionAttributes, build_speechlet_response(
            speech_output, reprompt_text, should_end_session, apiAccessToken))
        
def helpIntent(intent,session,apiAccessToken):
    sessionAttributes = session['attributes']
    maintainContextSpeech = sessionAttributes['maintainContextSpeech']
    speech_output = random.choice(Constants.helpMessage) + maintainContextSpeech
    reprompt_text = maintainContextSpeech
    should_end_session = False
    return build_response(sessionAttributes, build_speechlet_response(
        speech_output, reprompt_text, should_end_session, apiAccessToken))
    
def invalidDirection(session,apiAccessToken):
    sessionAttributes = session['attributes']
    maintainContextSpeech = sessionAttributes['maintainContextSpeech']
    speech_output = random.choice(Constants.invalidDirectionPrefix) + maintainContextSpeech
    reprompt_text = maintainContextSpeech
    should_end_session = False
    return build_response(sessionAttributes, build_speechlet_response(
        speech_output, reprompt_text, should_end_session, apiAccessToken))
        
    

def get_welcome_response(session,apiAccessToken,endpointId,device='x'):
    userData = getPregameData(session)
    numberOfVisits = userData["numberOfVisits"] + 1
    userData.update({"numberOfVisits" : numberOfVisits})
    updateUserData(userData)
    if numberOfVisits == 1:
        speech_output = random.choice(Constants.welcomeMessageFirstTime)
        reprompt_text = random.choice(Constants.welcomeMessageFirstTimeReprompt)
        maintainContext = random.choice(Constants.welcomeMessageFirstTimeMaintainContext)
    else:
        speech_output = random.choice(Constants.welcomeMessageAgain)
        reprompt_text = random.choice(Constants.welcomeMessageAgainReprompt)
        maintainContext = random.choice(Constants.welcomeMessageAgainMaintainContext)
    should_end_session = False
    session_attributes = {
        "currentState" : "welcome",
        "currentSpeech" : speech_output,
        "maintainContextSpeech" : maintainContext,
        "userData" : userData
    }
    return build_response(session_attributes, build_speechlet_response_HTML(
        speech_output, reprompt_text, should_end_session,apiAccessToken,device,endpointId))


def checkGadgetConnectivity(apiEndpoint,accessToken):
    headers = {
    'Authorization': 'Bearer ' + accessToken,
    'Content-Type': 'application/json',
        }
    
    response = requests.get(apiEndpoint + '/v1/endpoints', headers=headers, verify=False)
    print(response)
    print(response.text)
    respJson = json.loads(response.text)
    try:
        endpointId = respJson["endpoints"][0]["endpointId"]
    except:
        endpointId = "X"
    return endpointId




# --------------- Routers ----------------------

def on_launch(launch_request, session,apiAccessToken,endpointId,device):
    return get_welcome_response(session,apiAccessToken,endpointId,device)

def on_intent(intent_request, session,apiAccessToken,device):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "AMAZON.HelpIntent":
        return helpIntent(intent,session,apiAccessToken)
    elif intent_name == "AMAZON.CancelIntent":
	    return stopIntent(intent,session,apiAccessToken,device)
    elif intent_name == "AMAZON.StopIntent":
        return stopIntent(intent,session,apiAccessToken,device)
    elif intent_name == "" or intent_name == "AMAZON.StopIntent":
        return stopIntent(intent,session,apiAccessToken,device)
    elif intent_name == "moveIntent":
        return moveIntent(intent,session,apiAccessToken)
    elif intent_name == "restartIntent":
        return restartIntent(intent,session,apiAccessToken)
    elif intent_name == "continueIntent":
        return continueIntent(intent,session,apiAccessToken)
    elif intent_name == "pauseIntent":
        return pauseIntent(intent,session,apiAccessToken)
    elif intent_name == "AMAZON.YesIntent":
        return yesIntent(intent,session,apiAccessToken)
    elif intent_name == "AMAZON.NoIntent":
        return noIntent(intent,session,apiAccessToken,device)
    elif intent_name == "AMAZON.FallbackIntent":
        return fallbackIntent(session,apiAccessToken)
    else:
        raise ValueError("Invalid intent")

    

def getDevice(event):
    try:
        print("Here1")
        devicewidth=event['context']['Viewport']['currentPixelWidth']
        print("Here3")
        if devicewidth == 480:
            device = 'round'
        elif devicewidth == 960:
            device = 'small'
        elif devicewidth == 1024:
            device = 'medium'
        elif devicewidth >= 1920:
            device = 'tv'
        else:
            device = 'large'
        print("Here4")
    except:
        device = 'x'
    return device



# --------------- Main handler ------------------

def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    
    print("Call is made")
    print(event)
    print("This was the call")
    session = event['session']
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])
          
    apiAccessToken = event['context']['System']['apiAccessToken']
    print(event['context']['System'])
    
    apiEndpoint = event["context"]["System"]["apiEndpoint"]
    accessToken = event["context"]["System"]["apiAccessToken"]
    
    endpointId = checkGadgetConnectivity(apiEndpoint,accessToken)
    
    try:
        event['context']['System']['device']['supportedInterfaces']['Alexa.Presentation.HTML']['runtime']['maxVersion']
    except:
        return build_response({}, build_speechlet_response(
        random.choice(Constants.gameNotSupported), random.choice(Constants.gameNotSupported), True, apiAccessToken))
    
    device = getDevice(event)
    print("Device runnig this is " + device)
    
    
    try:
        sessionAttributes = session["attributes"]
    except:
        sessionAttributes = {}
    
    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")


    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'],apiAccessToken,endpointId,device)
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'],apiAccessToken,device)
    elif event['request']['type'] == "SessionEndedRequest":
        return stopIntent(event['request'], event['session'],apiAccessToken,device)
    elif event['request']['type'] == "CustomInterfaceController.EventsReceived":
        print("Received the EVENT from gadget")
        print(event["request"]["events"])
        direction = event["request"]["events"][0]['payload']['direction']
        print("Will be accling the WEBAPP from reomte")
        return build_response(sessionAttributes,build_speechlet_response_Move_button(direction,endpointId))
    elif event['request']['type'] == "Alexa.Presentation.HTML.Message":
        messageFromWeb = event['request']['message']
        print("In Message from web app")
        print(messageFromWeb)
        if messageFromWeb['requestType'] == "info" and messageFromWeb['request'] == "userBasic":
            return build_response(sessionAttributes, basicInfoToWeb(session))
        elif messageFromWeb['requestType'] == "speech" and messageFromWeb['request'] == "gameWon":
            try:
                gameWon = sessionAttributes['gameWon']
            except:
                gameWon = False
            if gameWon:
                return
            sessionAttributes.update({"maintainContextSpeech" : random.choice(Constants.gameWonMessageMaintainContext) , "currentState" : "gameEnded", "gameWon" : True})
            return build_response(sessionAttributes, build_speechlet_response(random.choice(Constants.gameWonMessage), random.choice(Constants.gameWonMessageReprompt), False,apiAccessToken))
        elif messageFromWeb['requestType'] == "update" and messageFromWeb['request'] == "bestScore":
            updateBestScore(session,messageFromWeb['bestScore'])
        elif messageFromWeb['requestType'] == "updateSession" and messageFromWeb['request'] == 'restart':
            sessionAttributes.update({'currentState' : 'gameStarted' , 'gameWon' : False})
            return build_response(sessionAttributes,{})
        elif messageFromWeb['requestType'] == "updateSession" and messageFromWeb['request'] == 'continue':
            print("User said Resume")
            sessionAttributes.update({'currentState' : 'gameStarted' , 'gameWon' : True})
            return build_response(sessionAttributes,{})
        elif messageFromWeb['requestType'] == "updateSession" and messageFromWeb['request'] == 'pause':
            print("Pause Button is pressed from the screen")
            sessionAttributes.update({'currentState' : 'gamePaused' , 'gameWon' : False})
            return build_response(sessionAttributes,{})
        elif messageFromWeb['requestType'] == "maxTileTillNow":
            try:
                maxTileTillNow = sessionAttributes['maxTileTillNow']
            except:
                maxTileTillNow = 4
            if messageFromWeb['request'] > maxTileTillNow:
                print("Updating the Max Tile now." + str(messageFromWeb['request']))
                sessionAttributes.update({'maxTileTillNow' : messageFromWeb['request']})
                return build_response(sessionAttributes,{})
        elif messageFromWeb['requestType'] == "speech" and messageFromWeb['request'] == "gameLost":
            sessionAttributes.update({"maintainContextSpeech" : random.choice(Constants.gameLostMessageMaintainContext) , "currentState" : "gameEnded", "gameWon" : False})
            return build_response(sessionAttributes, build_speechlet_response(random.choice(Constants.gameLostMessage), random.choice(Constants.gameLostMessageReprompt), False,apiAccessToken))
        elif messageFromWeb['requestType'] == "soundEffects":
            try:
                maxTileTillNow = sessionAttributes['maxTileTillNow']
            except:
                maxTileTillNow = 4
            if messageFromWeb['maxTileN'] > maxTileTillNow:
                maxTileTillNow = messageFromWeb['maxTileN']
                print("Updating the Max Tile now." + str(messageFromWeb['maxTileN']))
                sessionAttributes.update({'maxTileTillNow' : messageFromWeb['maxTileN']})
            return giveMovementResponse(sessionAttributes,maxTileTillNow,messageFromWeb['mergedTilesNo'],apiAccessToken)
                
        #return gotMessageFromWebApp(messageFromWeb)
