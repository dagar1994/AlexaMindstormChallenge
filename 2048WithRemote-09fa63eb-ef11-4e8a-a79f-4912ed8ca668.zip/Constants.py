# gameMainUrl = "https://bcb44ea0.ngrok.io"
# gameStopUrl = gameMainUrl + '/stop.html'
# gameMainUrlFiveInch = gameMainUrl + '/index_5inch.html'
# gameStopUrlFiveInch = gameMainUrl + '/stop_5inch.html'

gameBaseUrl = "https://voxogenic.com"
gameMainUrlFull = gameBaseUrl + "/2048"
gameStopUrlFull = gameBaseUrl + '/2048stop'
gameMainUrlFiveInch = gameBaseUrl + '/2048small'
gameStopUrlFiveInch = gameBaseUrl + '/2048smallstop'
gameMainUrl = "https://d1bae37b.ngrok.io"
gameStopUrl = gameBaseUrl + '/2048fullstop'


introSound = "<audio src='https://2048-html-game.s3.amazonaws.com/smooth_travels_aydppsu.mp3' /> "
#introSound = "<audio src='soundbank://soundlibrary/transportation/amzn_sfx_car_accelerate_01' /> "

leftAudio = "<audio src='https://2048-html-game.s3.amazonaws.com/1_.mp3' />"
rightAudio = "<audio src='https://2048-html-game.s3.amazonaws.com/4_.mp3' />"
upAudio = "<audio src='https://2048-html-game.s3.amazonaws.com/3_.mp3' />"
downAudio = "<audio src='https://2048-html-game.s3.amazonaws.com/6_.mp3' />"

mergeAudioOne = "<audio src='https://2048-html-game.s3.amazonaws.com/new/NEW_Socapex-big_punch.mp3' />"
mergeAudioTwo = "<audio src='https://2048-html-game.s3.amazonaws.com/new/NEW_Socapex-new_hits_5.mp3' />"
mergeAudioThree = "<audio src='https://2048-html-game.s3.amazonaws.com/new/NEW_Socapex-new_hits_6.mp3' />"

# Start Here



welcomeMessageFirstTime = [
    "{0}Hello and Welcome to 2 0 4 8 game. The rules are simple, join the numbers and get to the 2 0 4 8 tile. Give a voice command or swipe on the screen to move the tiles. When 2 tiles of same number touch, they merge into one. Now, start the game by either swiping on the screen, or by giving a voice command. For example, say, left to move the tiles left.".format(introSound),
    "{0}Hello! Welcome to 2 0 4 8 game. The rules are simple, join the numbers and get to the 2 0 4 8 tile. Give a voice command or swipe on the screen to move the tiles. When 2 tiles of same number touch, they merge into one. Now, start the game by either swiping on the screen, or by giving a voice command. For example, say, right to move the tiles right.".format(introSound),
    "{0}Greetings! Welcome to 2 0 4 8 game. The rules are simple, merge two tiles of the same number and repeat this until you get to the 2 0 4 8 tile. You can do this by giving a voice command or swiping on the screen.".format(introSound),
    "{0}Hello, welcome to 2 0 4 8 game. The rules are simple, merge two tiles of the same number and repeat this until you get to the 2 0 4 8 tile. You can do this by giving a voice command or swiping on the screen".format(introSound),
    "{0}Welcome to 2 0 4 8 game. The rules are simple, merge two tiles of the same number and repeat this until you get to the 2 0 4 8 tile. You can do this by swiping on the screen or by giving a voice command.".format(introSound),
    "{0}Welcome to 2 0 4 8 game. The rules are simple, merge two tiles of the same number and repeat this until you get to the 2 0 4 8 tile. You can do this by giving a voice command or swiping on the screen.".format(introSound),
    "{0}Hello and Welcome to 2 0 4 8 game. The rules are simple, join the numbers and get to the 2 0 4 8 tile. Give a voice command or swipe on the screen to move the tiles. When 2 tiles of same number touch, they merge into one. Now, start the game by either swiping on the screen, or by giving a voice command. For example, say, up to move the tiles upward.".format(introSound),
    "{0}Hello and Welcome to 2 0 4 8 game. The rules are simple, join the numbers and get to the 2 0 4 8 tile. Give a voice command or swipe on the screen to move the tiles. When 2 tiles of same number touch, they merge into one. Now, start the game by either swiping on the screen, or by giving a voice command. For example, say, down to move the tiles downward.".format(introSound),
    "{0}So glad to have you with us. Welcome to 2 0 4 8 game. The rules are simple, merge two tiles of the same number and repeat this until you get to the 2 0 4 8 tile. You can do this by giving a voice command or swiping on the screen.".format(introSound),
    "{0}Good to have you. Welcome to 2 0 4 8 game. The rules are simple, merge two tiles of the same number and repeat this until you get to the 2 0 4 8 tile. You can do this by giving a voice command or swiping on the screen.".format(introSound)

    ]
    
welcomeMessageAgain = [
    "{0}Welcome back to 2 0 4 8 game. Let's start. Swipe on the screen or give a voice command to continue. ".format(introSound),
    "{0}Hey, good to see you again. Let's play. Give a voice command or swipe on the screen to continue. ".format(introSound),
    "{0}Welcome back, my friend. Let's get started right away. Swipe on the screen or give a voice command to continue. ".format(introSound),
    "{0}Good to see you again. Welcome back to 2 0 4 8 game. Swipe on the screen or give a voice command to continue.".format(introSound),
    "{0}Great to have you again. Welcome back to 2 0 4 8 game. Swipe on the screen or give a voice command to continue.".format(introSound),
    "{0}Delight to have you back again. Welcome back to 2 0 4 8 game. Swipe on the screen or give a voice command to continue.".format(introSound),
    "{0}Greetings! Welcome back to 2 0 4 8 game. Swipe on the screen or give a voice command to continue.".format(introSound),
    "{0}It's good to have you back with us again. Welcome back to 2 0 4 8 game. Swipe on the screen or give a voice command to continue.".format(introSound),
    "{0}Welcome back to 2 0 4 8 game. Wonderful to have you again with us. Swipe on the screen or give a voice command to continue.".format(introSound)
    
    
    
    ]
    
welcomeMessageFirstTimeReprompt = [
    "Let's start the game by either swiping on the screen, or by giving a voice command like, say left to move the tiles left.",
    "Let's start the game by either swiping on the screen, or by giving a voice command like, say right to move the tiles right.",
    "Let's start the game by either swiping on the screen, or by giving a voice command like, say up to move the tiles upward.",
    "Let's start the game by either swiping on the screen, or by giving a voice command like, say down to move the tiles downward.",
    "You can start the game by swiping on the screen, or by giving a voice command.",
    "You can begin the game by swiping on the screen, or by giving a voice command.",
    "You may start the game by swiping on the screen, or by giving a voice command.",
    "You may begin the game by swiping on the screen, or by giving a voice command.",
    "Oops! I didn't get that. You may begin the game by swiping on the screen, or by giving a voice command.",
    "Apologies. I didn't get that. You may start the game by swiping on the screen, or by giving a voice command.",
    "I beg your pardon. I didn't quite catch that. You can start the game by swiping on the screen, or by giving a voice command.",
    "My apologies. I didn't understand that. You can begin the game by swiping on the screen, or by giving a voice command.",
    "Forgive me, I didn't quite get that. You can start the gamy by swiping on the screen, or by giving a voice command."
    ]

welcomeMessageAgainReprompt = [
    "Let's start the game by either giving a voice command or swiping on the screen.",
    "Let's play. Give a voice command or swipe on the screen to continue.",
    "Let's play to build the 2 0 4 8 tile. Swipe on the screen or give a voice command to continue.",
    "Let's start by either giving a voice command or by swiping on the screen.",
    "Let's begin by giving a voice command or by swiping on the screen.",
    "Let's begin by either giving a voice command or by swiping on the screen.",
    "Let us begin by giving a voice command or by swiping on the screen.",
    "Let us begin by either giving a voice command or by swiping on the screen.",
    "Let us start by either giving a voice command or by swiping on the screen.",
    "Let us start by giving a voice command or by swiping on the screen.",
    "You may start the game by either giving a voice command or by swiping on the screen.",
    "You may begin the game by either giving a voice command or by swiping on the screen.",
    "You can start the game by either giving a voice command or by swiping on the screen.",
    "You can begin the game by either giving a voice command or by swiping on the screen.",
    "You may want to start the game by either giving a voice command or by swiping on the screen.",
    "You may want to begin the game by either giving a voice command or by swiping on the screen."
    
    ]

welcomeMessageFirstTimeMaintainContext = [
    "You have to start the game by either swiping on the screen, or by giving a voice command. For example, say left, to move the tiles left.",
    "You have to start the game by either swiping on the screen, or by giving a voice command. For example, say right, to move the tiles right.",
    "You have to start the game by either swiping on the screen, or by giving a voice command. For example, say up, to move the tiles upward.",
    "You have to start the game by either swiping on the screen, or by giving a voice command. For example, say down, to move the tiles downward.",
    "You may start the game by either swiping on the screen, or by giving a voice command. For example, say left, to move the tiles left.",
    "You may start the game by either swiping on the screen, or by giving a voice command. For example, say right, to move the tiles right.",
    "You may start the game by either swiping on the screen, or by giving a voice command. For example, say up, to move the tiles upward.",
    "You may start the game by either swiping on the screen, or by giving a voice command. For example, say down, to move the tiles downward.",
    "You can start the game by either swiping on the screen, or by giving a voice command. For example, say left, to move the tiles left.",
    "You can start the game by either swiping on the screen, or by giving a voice command. For example, say right, to move the tiles right.",
    "You can start the game by either swiping on the screen, or by giving a voice command. For example, say up, to move the tiles upward.",
    "You can start the game by either swiping on the screen, or by giving a voice command. For example, say down, to move the tiles downward.",
    "To start the game, you may swipe on the screen, or give a voice command. For example, say left, to move the tiles left.",
    "To start the game, you may swipe on the screen, or give a voice command. For example, say right, to move the tiles right.",
    "To start the game, you may swipe on the screen, or give a voice command. For example, say up, to move the tiles upward.",
    "To start the game, you may swipe on the screen, or give a voice command. For example, say down, to move the tiles downward.",
    "To start the game, you can swipe on the screen, or give a voice command. For example, say left, to move the tiles left.",
    "To start the game, you can swipe on the screen, or give a voice command. For example, say right, to move the tiles right.",
    "To start the game, you can swipe on the screen, or give a voice command. For example, say up, to move the tiles upward.",
    "To start the game, you can swipe on the screen, or give a voice command. For example, say down, to move the tiles downwards."
    
    
    ]

welcomeMessageAgainMaintainContext = [
    "You have to start the game by either giving a voice command or swiping on the screen.",
    "To continue, either swipe on the screen or give a voice command.",
    "Keep playing by swiping on the screen or giving a voice input.",
    "Start playing the game by swiping on the screen or giving a voice command.",
    "To start the game, give a voice command to move the tiles.",
    "You may start the game by either swiping on the screen, or by giving a voice command.",
    "You can start the game by either swiping on the screen, or by giving a voice command.",
    "To start the game, you can swipe on the screen, or give a voice command.",
    "To start the game, you may swipe on the screen, or give a voice command.",
    "To begin the game, you can either swipe on the screen or give a voice command.",
    "To begin the game, you may swipe on the screen, or give a voice command.",
    "You may begin the game by either swiping on the screen, or by giving a voice command.",
    "You can begin the game by either swiping on the screen, or by giving a voice command."
    ]
    
    

# movementMessage = [
#     "Okay, moving the tiles {0}. Now make your next move.",
#     "Tiles going {0}. You are doing great. Make your next move now.",
#     "Great. You are doing it right. Take the next step.",
#     "Awesome. You are smarter than I thought. Make your next move.",
#     "That's amazing. How did you think of this move. Now, make your next move.",
#     "That was a smart move. Think and make the next one.",
#     "That was awesome. I think you have what it take to win this game. Take the next chance.",
#     "That's stunning. You are playing it right. Make you next move.",
#     "It was an awesome move. Make the next one even better.",
#     "How did you think of that move. That was really smart. Now make the next.",
#     "Stunning move. Look at the board and make the next one.",
#     "Impressive. You are smart. Now, prove your smartness in the next move again.",
#     "Excellent work. Think deep and make your next move.",
#     "{0} it is. Okay, now take your next chance.",
#     "I know it takes time. Keep on playing.",
#     "2 0 4 8 in not that far away. Let's test your smartness in the next move.",
#     "That was excellent. You are just there, I can feel it. Next move now.",
#     "{0} is the direction to choose. See the board and make the next one.",
#     "Next.",
#     "Next chance.",
#     "Next turn"

#     ]

movementMessage = [
    "Good. Make your next move.",
    "Next.",
    "Next chance.",
    "Next turn.",
    "Great. Next.",
    "Stunning. Next.",
    "Great. Next",
    "Awesome. Go again.",
    "Excellent. Go again.",
    "Excellent. Next",
    "Excellent move. Next.",
    "Impressive. Go again.",
    "Excellent. Go again.",
    "Impressive move. Next."
    "Go again",
    "Make the next move",
    "{0} it is. Next.",
    "Moving {0}. Go again.",
    "{0} it is. Go again.",
    "Moving {0}. Next.",
    "Okay. Next."

    ]
    



movementReprompt = [
    "Make your next move towards the win.",
    "What will be your next move?",
    "Time to make your next move.",
    "Time to make your next move. Make it count.",
    "What is your next move towrds the win?",
    "What is your next move?",
    "Tell me your next move.",
    "Tell me your next move for the win.",
    "Specify where you would want to move next.",
    "Please specify where you would want to move next.",
    "Please tell me your next move.",
    "Please specify your next move.",
    "Please tell me in which direction you would like to move.",
    "Please specify in which direction you would like to move.",
    "Time for your next move now.",
    "Time for your next move.",
    "It is time for your next move now.",
    "It's time for your next move now.",

    
    
    
    
    ]

movementMaintainContext = [
    "You have to say a direction, or swipe on the screen to continue.",
    "To continue with the game, you have to say a direction, or swipe on the screen.",
    "To continue with the game, swipe on the screen, or say the direction you want the tiles to move.",
    "To move ahead with the game, you can either swipe on the screen, or tell the direction you want the tiles to move.",
    "You have to tell the direction, or swipe on the screen to move ahead.",
    "To continue with the game, you can either swipe on the screen, or say the direction you want the tiles to move.",
    "To continue with the game, you can either tell the direction you want the tiles to move, or swipe on the screen.",
    "You may tell the direction, or swipe on the screen to move ahead.",
    "You can either tell the direction, or swipe on the screen to move ahead.",
    "You may either tell the direction you want the tiles to move, or swipe on the screen to continue."
    
    ]
    
maintainContextPrefix = [
    "Sorry, I could not understand that. ",
    "Hey, I might not be able to help you with that. ",
    "Sorry, I might not be able to help you right now with that. ",
    "Hey, I can't help you with that right now. ",
    "Sorry, I missed what you just said. ",
    "Oops, I am not that smart to help you with it. ",
    "Apologies, I didn't catch that.",
    "Oops, sorry! I didn't quite catch that.",
    "My apologies, I didn't get that.",
    "Sorry about that, I didn't catch that.",
    "Forgive me, I didn't quite catch that.",
    "Sorry but I didn't get that.",
    "Oops! I can't help you with that.",
    "Sorry! I can't help you with that.",
    "My bad, I may not be able to help you with that.",
    "I'm sorry. I may not be able to help with that.",
    "I'm sorry about that. I won't be able to help you with that.",
    "My apologies. I won't be able to help you with that.",
    "Whoops! I may not be able to help you with that.",
    "Sorry. I am unable to help you with that.",
    "Uh- oh! I am unable to help you with that.",
    "Oh no! I am unable to help you with that.",
    "Oh, dear! I am unable to help you with that."
    
    
    ]
    
invalidDirectionPrefix = [
    "Sorry, I could not understand the direction. ",
    "Sorry, I missed what you just said. ",
    "Sorry, I was not able to understand what you just said.",
    "My apologies, I couldn't get what you just said.",
    "Oops, I did not get that.",
    "Oops, sorry! I didn't quite catch that.",
    "Sorry about that, I didn't understand what you just said.",
    "Uh-oh. I didn't get that.",
    "Oh shucks! I didn't get that.",
    "Apologies. I didn't understand that.",
    "Forgive me, I didn't quite catch that."
    
    ]

gameNotSupported = [
    "Sorry, this game is only available on Echo Show and Fire T.V.",
    "Sorry, this device does not support this game. You can try it out on an Echo Show or Fire T.V. device, or you can visit voxogenic dot com slash 2 0 4 8. ",
    "Sorry, you cannot play this game on this device. Try it on the Echo Show or the Fire T.V. devices. ",
    "Sorry, you can't play this game on this device. Try it on the Echo Show or the Fire T.V. devices, or you can visit voxogenic dot com slash 2 0 4 8. ",
    "My apologies, the game is only available on Echo Show and Fire T.V.",
    "Oops, sorry! The game is only available on Echo Show and Fire T.V.",
    "My apologies. This device doesn't support this game. You can try it out on Echo Show, or Fire T.V. . You can also visit our website. Voxogenic dot com, slash 2 0 4 8.",
    "Oops, sorry. This device doesn't support this game. You can try it out on Echo Show, or Fire T.V. . You can also visit our website. Voxogenic dot com, slash 2 0 4 8.",
    "Apologies. This device doesn't support this game. You can try it out on Echo Show, or Fire T.V. . You can also vist our website. Voxogenic dot com, slash 2 0 4 8.",
    "Oh no! This device doesn't support this game. You can try it out on Echo Show, or Fire T.V. . You can also vist our website. Voxogenic dot com, slash 2 0 4 8.",
    "Uh-oh! This device doesn't support this game. You can try it out on Echo Show, or Fire T.V. . You can also visit our website. Voxogenic dot com, slash 2 0 4 8.",
    "Whoops! This device doesn't suport this game. You can try it out on Echo Show, or Fire T.V. . You can also vist our website. Voxogenic dot com, slash 2 0 4 8.",
    "Sorry about that. This device doesn't support this game. You can try it out on Echo Show, or Fire T.V.. You can also visit our website. Voxogenic dot com, slash 2 0 4 8.",
    "Oops, sorry. This game is only available on Echo Show and Fire T.V.",
    "My apologies. You can't play this game on the this device. You can refer to the supported devices in the skill's description.",
    "Oops, sorry! The game is not supported on this device. You can try this game only on Echo Show and Fire T.V.",
    "Uh-oh! The game is not supported on this device. You can try this game only on Echo Show and Fire T.V."
    

    
    
    
    
    ]
    
# continueMessage = [
#     "<say-as interpret-as='interjection'>roger</say-as>. continue playing and create the maximum number tile you can.",
#     "<say-as interpret-as='interjection'>all righty</say-as>. That's more like it. Continue playing and create the maximum you can.",
#     "<say-as interpret-as='interjection'>righto</say-as>. That's what I thought. Continue playing and do the best you can.",
#     "<say-as interpret-as='interjection'>roger</say-as>. It is expected from a champion like you. Continue playing and create the maximum number tile that you can.",
#     "<say-as interpret-as="interjection">awright</say-as>. A legend in the making. Continue towards 2 0 4 8.",
#     "<say-as interpret-as="interjection">okey dokey</say-as>. Are you a legend? Because you seem to be playing like one. Onwards to 2 0 4 8.",
#     "<say-as interpret-as="interjection">uh huh</say-as>. There you go! Keep going, you are getting closer.",
#     "<say-as interpret-as="interjection">way to go</say-as>. You're getting the hang of this. Continue towards 2 0 4 8.",
#     "<say-as interpret-as="interjection">yup</say-as>. Nice move there! 2 0 4 8 awaits."
#     ]

continueMessage = [
    "Alright",
    "Okay",
    "Affirmative",
    "Alright then.",
    "Okay then.",
    "Got it.",
    "Sure thing.",
    "Sure.",
    "Okay, sure.",

    
    
    ]

continueMessageReprompt = [
    "Continue playing and create the maximum number tile you can.",
    "Continue playing and do the best you can.",
    "Continue and create the maximum number you can.",
    "Keep going, and get the maximum number you can.",
    "Keep at it, and get to the maximum number you can.",
    "Keep continuing, and get to 2 0 4 8.",
    "Keep at it, and get to 2 0 4 8.",
    "Continue adding the numbers and get to 2 0 4 8.",
    "Keep adding the numbers and get to 2 0 4 8.",
    "Continue adding the tiles and get to 2 0 4 8.",
    "Keep adding the tiles and get to 2 0 4 8.",
    "Keep adding the tiles and get to the maximum number you can.",
    "Continue adding the tiles and get to the maximum number you can."
    
    
    ]

continueMessageMaintinContext = [
    "Now, continue playing by giving a voice command, or swiping on the screen.",
    "You can continue playing by giving a voice command, or by swiping on the screen.",
    "You may continue the game by giving a voice command, or by swiping on the screen.",
    "Now, keep playing the game by giving a voice command, or by swiping on the screen.",
    "Now, you may continue the game by giving a voice command, or by swiping on the screen.",
    "Now, you can continue the game by giving a voice command, or by swiping on the screen."
    ]
    
# resumeMessage = [
#     "<say-as interpret-as='interjection'>all righty</say-as>, continue playing from where you left. ",
#     "That's more like it. Continue playing and create the maximum you can. ",
#     "That's what I thought. Continue playing and do the best you can. ",
#     "It is expected from a champion like you. Continue playing and create the maximum number tile that you can. "
#     ]
    
resumeMessage = [
    "<say-as interpret-as='interjection'>all righty</say-as>.",
    "<say-as interpret-as='interjection'>good luck</say-as>.",
    "<say-as interpret-as='interjection'>okey dokey</say-as>.",
    "It is expected from a champion like you. Continue playing and create the maximum number tile that you can.",
    "<say-as interpret-as='interjection'>awrighty</say-as>.",
    "<say-as interpret-as='interjection'>awesome</say-as>.",
    "<say-as interpret-as='interjection'>righto</say-as>.",
    "<say-as interpret-as='interjection'>uh huh</say-as>.",
    
    
    ]

resumeMessageReprompt = [
    "Continue playing and create the maximum number tile you can. ",
    "Continue playing and do the best you can. ",
    "Continue and create the maximum number you can.",
    "Keep at it, and get to 2 0 4 8.",
    "Keep going, and get the maximum number you can.",
    "Keep at it, and get to the maximum number you can.",
    "Continue adding the numbers and get to 2 0 4 8.",
    "Keep adding the tiles and get to the maximum number you can.",
    "Continue adding the tiles and get to 2 0 4 8."
    ]

resumeMessageMaintinContext = [
    "Now, continue playing by giving a voice command, or swiping on the screen.",
    "You can continue playing by giving a voice command, or by swiping on the screen.",
    "You may continue the game by giving a voice command, or by swiping on the screen.",
    "Now, you can continue the game by giving a voice command, or by swiping on the screen.",
    "Now, you may continue the game by giving a voice command, or by swiping on the screen."
    
    
    ]

restartMessage = [
    
    "<say-as interpret-as='interjection'>all righty</say-as>. I have reset the board for you. Now, continue by giving a voice command or swiping on the screen.",
    "<say-as interpret-as='interjection'>okey dokey</say-as>. Let's start again. Swipe on the screen or give a voice command to continue.",
    "<say-as interpret-as='interjection'>righto</say-as>. I have reset the board for you. Please swipe on the screen of give a voice command to continue.",
    "<say-as interpret-as='interjection'>okey dokey</say-as>. Let's start the game again. Please give a voice command or swipe on the screen to continue.",
    "<say-as interpret-as='interjection'>all righty</say-as>. I've reset the board for you. Let's see how you perform this time. Give a voice command or swipe on the screen to continue.",
    "<say-as interpret-as='interjection'>all righty</say-as>. Starting the game again. I hope you win it this time. Swipe on the screen or give a voice command to make your first move.",
    "<say-as interpret-as='interjection'>awrighty</say-as>. Let us start again. Time to get to 2 0 4 8. You can swipe on the screen, or you can give a voice command.",
    "<say-as interpret-as='interjection'>roger</say-as>. Time for a new game, get ready! You may swipe on the screen, or give a voice command to begin.",
    "Affitmative. Time to start a new game. You can start by swiping on the screen, or by giving a voice command.",
    "Roger that. The board has been reset. You may start by swiping on the screen, or by giving a voice command.",
    "Alright then. The board has been reset. You may start the game by swiping on the screen, or by giving a voice command.",
    "Okay then. A fresh start. You can start the game by swiping on the screen, or by giving a voice command.",
    "Sure thing. Ready up! You can either start by swiping on the screen, or by giving a voice command."
    ]
    
restartMessageReprompt = [
    
    "Now, continue by giving a voice command, or swiping on the screen.",
    "You have to start the game by either giving a voice command, or swiping on the screen.",
    "To continue, either swipe on the screen, or give a voice command.",
    "Keep playing by swiping on the screen, or giving a voice input.",
    "Start playing the game by swiping on the screen, or giving a voice command.",
    "To start the game, give a voice command to move the tiles.",
    "You may start the game by either swiping on the screen, or by giving a voice command.",
    "You can start the game by either swiping on the screen, or by giving a voice command.",
    "Now, you can start by swiping on the scree, or by giving a voice command.",
    "Now, you may start by swiping on the screen, or by giving a voice command.",
    
    
    ]
    
restartMessageMaintainContext = [
    
    "Continue by giving a voice command or swiping on the screen.",
    "You have to start the game by either giving a voice command or swiping on the screen.",
    "To continue, either swipe on the screen or give a voice command.",
    "Keep playing by swiping on the screen or giving a voice input.",
    "Start playing the game by swiping on the screen or giving a voice command.",
    "To start the game, give a voice command to move the tiles.",
    "To begin the game, either swipe on the screen, or by giving a voice command.",
    "To go ahead with the game, you can either swipe on the screen, or by giving a voice command.",
    "To go ahead with the game, you may swipe on the screen, or give a voice command.",
    "To start the game, you can either swipe on the screen, or give a voice command.",
    "To start the game, you may either swipe on the screen, or give a voice command.",
    "To continue, you can either swipe on the screen, or give a voice command.",
    "To continue, you may either swipe on the screen, or give a voice command.",
    
    
    ]

pauseMessage = [
    "Alright, the game is paused. Say, resume whenever you are ready.",
    "Okay, the game is now paused. Say, resume whenever you are ready.",
    "Affirmative, the game is paused now. Say, resume whenver you are ready to go.",
    "Roger that. The game is now pause. Say, resume whenever you are ready to go.",
    "Sure, the game is paused now. Say, resume whenever you want to continue.",
    "Alright then, the game is now paused. Say, resume whenever you want to continue.",
    "Okay then. The game is paused now. Say, resume whenever you want to continue.",
   
    ]

pauseMessageReprompt = [
    "Say, resume whenever you are ready.",
    "Say, resume whenever you are ready to continue."
    ]

pauseMessageMaintainContext = [
    "Now, you have to say resume whenever you are ready.",
    "You can say, resume, to continue with the game."
    "You may say, resume, to continue with the game.",
    "Now, you can say resume, whenever you are ready to go.",
    "Now, you may say resume, whenever you are ready to continue."
    ]

gameWonMessage = [
    
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. You won the game. Would you like to try again, or continue playing to create a higher number tile.",
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. You did it. Congratulations. Now, would you like to play again or continue the game to create a higher number tile.",
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. Congratulations, you won the game. What would you like to do now. Keep on playing, or Play the game again.",
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. Congratulations, you did it. Now, to keep on playing say, keep going. To play the game again say, play again.",
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. Congrats, you won the game. I have not been able to do it myself till now. Now, to keep on playing say, keep going. To play the game again say, play again.",
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. You won the game. You are amongst the few people who have been able to win this game. What would you like to do now. Keep on playing, or Play the game again.",
    "<break time='6s'/> <say-as interpret-as='interjection'>Hurray</say-as>. Hey you just won the game. It's not easy, but you played like a champion. What would you like to do now. Keep on playing, or Play the game again.",
    "<break time='6s'/> <say-as interpret-as='interjection'>ace</say-as>. A legend is born. Congratulations on winning the game. What would you like to do now? Continue with the game, or start a new game.",
    "<break time='6s'/> <say-as interpret-as='interjection'>bravo</say-as>. You are a true genius! Congrats on winning the game. So what would you like to do now? Continue with the same game, or start a new game?",
    "<break time='6s'/> <say-as interpret-as='interjection'>awesome</say-as>. You've just won the game. You truly have the x factor. So what would you like to do now? Continue with the game, or start a new game?",
    "<break time='6s'/> <say-as interpret-as='interjection'>well done</say-as>. You have beaten the game. You are Godlike! So what would you like to do now? Continue, or start a new game?",
    "<break time='6s'/> <say-as interpret-as='interjection'>woo hoo</say-as>. Congratulations on beating the game. Enjoy this moment. So what would you like to do now? Continue, or start a new game?",
    "<break time='6s'/> <say-as interpret-as='interjection'>wowza</say-as>. You sir, are remarkable. Congrats on winning the game. What would you like to do now? Continue with the same game, or start a new game?",
    "<break time='6s'/> <say-as interpret-as='interjection'>yippee</say-as>. Truly eye-catching stuff. Congrats on the win. What would you like to do now? Continue with same game, or start a new game?",
    

    
    ]

gameWonMessageReprompt = [
    "Would you like to try again, or continue playing to create a higher tile.",
    "What would you like to do now. Keep on playing, or Play the game again.",
    "Now, to keep on playing say, keep going. To play the game again say, play again.",
    "Now, would you like play again or continue the game to create a higher number tile.",
    "So what would you like to do now? Continue with the same game, or start a new game.",
    "So would you like to continue with the same game, or start a new game?"
    "So would you like to continue with the same game to create a higher tile, or start a new game?",
    "What would you like to do next? Continue with the same game or start a new game?",
    "Would you like to start a new game, continue with the same game?",
    "Now, what would you like to do? Continue with the same game, or start a new game.",
    "Now, would you like to start a new game, or continue with the same game."
    ]
    
gameWonMessageMaintainContext = [
    "Now, would you like to try the game again, or continue playing?",
    "Would you like to try again, or continue playing to create a higher tile.",
    "What would you like to do now. Keep on playing, or Play the game again.",
    "Now, to keep on playing say, keep going. To play the game again say, play again.",
    "Now, would you like play again or continue the game to create a higher number tile.",
    "What would you like to do next? Continue with the same game or start a new game?",
    "So what would you like to do now? Continue with the same game, or start a new game.",
    "So would you like to continue with the same game, or start a new game?",
    "So would you like to continue with the same game to create a higher tile, or start a new game?",
    ""
    
    ]
    
gameLostMessage = [
    "<say-as interpret-as='interjection'>oh</say-as>. You lost the game. Would you like to try again?",
    "<say-as interpret-as='interjection'>oh snap</say-as>. You are out of moves now. Would you like to play again?",
    "<say-as interpret-as='interjection'>oh dear</say-as>. No more moves left my friend. Would you like to try again?",
    "<say-as interpret-as='interjection'>oh my</say-as>. Sorry, you are out of moves now. Do you want to play again?",
    "<say-as interpret-as='interjection'>uh oh</say-as>. Hey, the board is full. Do you want to try again?",
    "<say-as interpret-as='interjection'>boo hoo</say-as>. The board is now full. Would you like to try again?",
    "<say-as interpret-as='interjection'>jeepers creepers</say-as>. The board is full now. Would you like to try again?",
    "<say-as interpret-as='interjection'>ouch</say-as>. You've lost the game as the board is now full. Would you like to try again?",
    "<say-as interpret-as='interjection'>ow</say-as>. You've lost the game. Do you want to give it another try?",
    "<say-as interpret-as='interjection'>sigh</say-as>. The board is now full, and as a result you've lost the game. Would you like to give it another try?",
    "<say-as interpret-as='interjection'>uff</say-as>. You have ran out of move, my friend. Would you like to give it another try?",
    "<say-as interpret-as='interjection'>whoops a daisy</say-as>. You have ran out of moves and as a result you've lost the game. Do you want to try again?"
    
    ]

gameLostMessageReprompt = [
    "Would you like to try again?",
    "Would you like to play again?",
    "Do you want to play again?",
    "Do you want to try again?",
    "Do you want another try?",
    "Would you like to have another try?",
    "Do you want to play the game one more time?",
    "Would you like to try one more time?",
    "Would you like to give it another try?",
    "Do you want to give it another try?",
    "Would you like to start a new game?",
    "Do you want to start a new game?"
    ]
    
gameLostMessageMaintainContext = [
    "Now, would you like to try the game again?",
    "Now, Would you like to play again?",
    "Now, Do you want to play again?",
    "Now, Do you want to try again?",
    "Now, do you want to play the game again?",
    "Now, would you like to give it another try?",
    "Now, do you want to give it another try?",
    "Now, would you like to start a new game?",
    "Now, do you want to start a new game?",
    "Now, would you like to give it another chance?",
    "Now, do you want to give it another chance?"
    ]
    
restartNoMessage = [
    "Okay, Thank you for playing 2 0 4 8 game. Hope to see you soon.",
    "Alright, thanks for playing 2 0 4 8. Come back again for another game.",
    "Alright, Thanks for playing with me. I wish to see you again soon.",
    "Okay, hope you liked the game.",
    "Okay, if you like the game leave us a review on the Alexa Skills Store",
    "Okay then. If you enjoyed the game, do leave us a review on the Alexa Skills Store.",
    "Alright then. If you had fun playing the game, do leave us a review on the Alexa Skills Store.",
    "Okay then. Thank you for playing 2 0 4 8 game. If you enjoyed the game, do leave us a review on the Alexa Skills Store.",
    "Alright then. Thank you for playing 2 0 4 8 game. If you had fun playing the game, do leave us a review on the Alexa Skills store."
    ]
    
restartNoMessageReprompt = [
    
    "Thank you for playing 2 0 4 8 game. Hope to see you soon.",
    "Thanks for playing 2 0 4 8 game. Hope to have you soon.",
    "Thank you so much for playing 2 0 4 8 game. Hope to see you soon for another fun game.",
    "Thanks a ton for playing 2 0 4 8 game. Hope to see you next time.",
    "Thank you. It was so great to have you. Hope you enjoyed 2 0 4 8 game.",
    "Thank you so much. It was a pleasure to have you check out 2 0 4 8 game.",
    "Thanks a ton. It was so good to have you check out 2 0 4 8 game.",
    "Thank you so much for trying out 2 0 4 8 game. Hope to see you soon.",
    "Thank you for trying 2 0 4 8 game. Hope to catch you next time."
    
    ]
    
restartNoMessageMaintainContext = [
    
    "Thank you for playing 2 0 4 8 game. Hope to see you soon.",
    "Thanks for playing 2 0 4 8 game. Hope to have you soon.",
    "Thank you so much for playing 2 0 4 8 game. Hope to see you soon for another fun game.",
    "Thank you so much. It was a pleasure to have you check out 2 0 4 8 game.",
    "Thanks a ton. It was so good to have you check out 2 0 4 8 game.",
    "Thank you so much for trying out 2 0 4 8 game. Hope to see you soon."
    
    
    ]
    
stopMessage = [
    "Okay, Thank you for playing 2 0 4 8. Hope to see you soon.",
    "Alright, thanks for playing 2 0 4 8. Come back again for another game.",
    "Alright, Thanks for playing with me. I wish to see you again soon.",
    "Okay, hope you liked the game. I Wish to see you again.",
    "Okay, if you like the game leave us a review on the Alexa Skills Store. Hope to see you soon.",
    "Thank you. Hope you enjoyed the game.",
    "No problem. Come back again for another game.",
    "Sure thing. Come back anytime for a fun fuelled game.",
    "Alright then, thanks for playing 2 0 4 8. Come back anytime for another game.",
    "Okay then, thanks for playing 2 0 4 8. I wish to see you soon.",
    "Sure, thank you for playing 2 0 4 8. Come back soon for an exciting game.",
    "Affirmative, thanks a ton for playing 2 0 4 8. Hope to catch you really soon for yet another game of 2 0 4 8."
    
    ]
    
stopMessageReprompt = [
    
    "Thank you for playing 2 0 4 8 game. Hope to see you soon.",
    "Thank you so much for playing 2 0 4 8 game. Hope to catch you soon.",
    "Thanks a ton for playing 2 0 4 8 game. I hope to see you soon for another game.",
    "Thanks a bunch for checking out 2 0 4 8 game. It would be a pleasure to see you again.",
    "Thank you so much for checking out 2 0 4 8 game. It would be great to have you again.",
    "Thank you for checking out 2 0 4 8. It would be awesome to have you again with."
    "Thanks for checking out 2 0 4 8 game. It would be exciting to have you again with us."
    
    
    ]
    
stopMessageMaintainContext = [
    
    "Thank you for playing 2 0 4 8 game. Hope to see you soon.",
    "Thank you so much for playing 2 0 4 8 game. Hope to catch you soon.",
    "Thanks a ton for playing 2 0 4 8 game. I hope to see you soon for another game.",
    "Thanks a bunch for checking out 2 0 4 8 game. It would be a pleasure to see you again.",
    "Thank you so much for checking out 2 0 4 8 game. It would be great to have you again.",
    "Thank you for checking out 2 0 4 8. It would be awesome to have you again with.",
    "Thanks for checking out 2 0 4 8 game. It would be exciting to have you again with us."
    
    
    
    
    ]

helpMessage = [
    "Okay. The rules are simple, join the numbers and get to the 2 0 4 8 tile. Give a voice command or swipe on the screen to move the tiles. When 2 tiles of same number touch, they merge into one.",
    "Alright. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say left, to move the tiles left.",
    "Alright. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say right, to move the tiles right.",
    "Alright. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say up, to move the tiles upwards.",
    "Alright. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say down, to move the tiles downwards.",
    "Affirmative. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say left, to move the tiles left.",
    "Affirmative. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say right, to move the tiles right.",
    "Affirmative. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say up, to move the tiles upwards.",
    "Affirmative. The rules are simple, merge the tiles with same numbers to create a bigger tile. You may do this my swiping on the screen, or by giving a voice command. For example say down, to move the tiles downwards.",
    "Okay. The rules are simple, you are to merge the tile with same numbers to create a bigger tile. Continue this until you get to the 2 0 4 8 tile. You may do this my swiping on the screen, or by giving a voice command. For example say left, to move the tiles left.",
    "Okay. The rules are simple, you are to merge the tile with same numbers to create a bigger tile. Continue this until you get to the 2 0 4 8 tile. You may do this my swiping on the screen, or by giving a voice command. For example say right, to move the tiles right.",
    "Okay. The rules are simple, you are to merge the tile with same numbers to create a bigger tile. Continue this until you get to the 2 0 4 8 tile. You may do this my swiping on the screen, or by giving a voice command. For example say up, to move the tiles upwards.",
    "Okay. The rules are simple, you are to merge the tile with same numbers to create a bigger tile. Continue this until you get to the 2 0 4 8 tile. You may do this my swiping on the screen, or by giving a voice command. For example say down, to move the tiles down."
    
    
    ]