# -*- coding: utf-8 -*-
from __future__ import print_function
import random
from datetime import datetime
import json
import requests



def build_speechlet_response_start_listener(title, cardContent,output, reprompt_text, should_end_session,endpointId):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        "directives": [
            {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 90000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND_AND_TERMINATE"  
                }
            }
        ],
        'shouldEndSession': should_end_session
    }


def build_speechlet_response_robo(title,cardContent , output, reprompt_text, should_end_session,endpointId,typeOfAction):
    return { 
        
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + " </speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'directives': [
            {
                "type": "CustomInterfaceController.SendDirective",
                "endpoint": {
                  "endpointId": endpointId
                },
                "header": {
                  "namespace": "Custom.Mindstorms.Gadget",
                  "name": "Control"
                },
                "payload": { 
                  "direction": "clockwise",
                  "times": 5,
                  "type" : typeOfAction,
                  "command" : "sentry"
                }
              },
              {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 60000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND_AND_TERMINATE"  
                }
            }
            ],
        'shouldEndSession': should_end_session
    }


def build_speechlet_response(title, cardContent, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak>" + output + "</speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': "<speak>" + reprompt_text + "</speak>"
            }
        },
        'shouldEndSession': should_end_session
    }

def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


#----------------------------------------------------------------------------------------------

def checkGadgetConnectivity(apiEndpoint,accessToken):
    headers = {
    'Authorization': 'Bearer ' + accessToken,
    'Content-Type': 'application/json',
        }
    
    response = requests.get(apiEndpoint + '/v1/endpoints', headers=headers, verify=False)
    print(response)
    print(response.text)
    respJson = json.loads(response.text)
    try:
        endpointId = respJson["endpoints"][0]["endpointId"]
    except:
        endpointId = "X"
    return endpointId

def get_welcome_response(session,event):
    apiEndpoint = event["context"]["System"]["apiEndpoint"]
    accessToken = event["context"]["System"]["apiAccessToken"]
    endpointId = checkGadgetConnectivity(apiEndpoint,accessToken)
    
    if endpointId == "X":
        output = "<audio src='https://divyanshubucket.s3.amazonaws.com/TicTacToe-ThemeSong.mp3'/> Hello, Welcome to Statue Dance. Your gadget is not connected right now."
        title = "Welcome"
        cardContent = output
        reprompt_text = output
        should_end_session = False
        session_attributes = {}
    else:    
        output = "<audio src='https://divyanshubucket.s3.amazonaws.com/TicTacToe-ThemeSong.mp3'/> Welcome to the fun game of Statue Dance. Would you like me to start the game or check out the rules?"
        title = "Welcome"
        cardContent = output
        reprompt_text = "Play the game or checkout the rules?"
        should_end_session = False
        session_attributes = {
            "currentState" : "welcome",
            "endpointId":endpointId,
            "spins":0
        }
    return build_response(session_attributes, build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))
        
        
def cancel_response(intent,session):
    session_attributes = {}
    card_title = "Thank you"
    speech_output = """
	Thank you for playing. Come back again.
			""".strip() 
    reprompt_text = speech_output
    cardContent = speech_output
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, cardContent,speech_output, reprompt_text, should_end_session))
        
def rulesIntent(intent,session):
    try:
        session_attributes = session['attributes'] 
    except:
        session_attributes = {} 
    card_title = "Thank you"
    speech_output = """
	Okay, the rules are simple, I will start playing a song, and you have to start dancing. When I say statue, you have to stop in which ever position you are. and stay in it for some time. Ready to play now?
			""".strip() 
    reprompt_text = speech_output
    cardContent = speech_output
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
        card_title, cardContent,speech_output, reprompt_text, should_end_session))
        
        
def noIntent(intent,session):
    try:
        session_attributes = session['attributes'] 
    except:
        session_attributes = {} 
    card_title = "Thank you"
    speech_output = """
	Okay, No problem. Come back for another game of statue dance. Thanks!
			""".strip() 
    reprompt_text = speech_output
    cardContent = speech_output
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, cardContent,speech_output, reprompt_text, should_end_session))
        
        
        
def yesIntent(intent,session):
    try:
        session_attributes = session['attributes'] 
    except:
        session_attributes = {} 
    endpointId = session['attributes']['endpointId']
    card_title = "Thank you"
    speech_output = """
	Okay, Let's play. I will now play the song and you have to start dancing. <audio src='https://robodance.s3.amazonaws.com/NEW_dance.mp3'/>
			""".strip() 
    reprompt_text = speech_output
    cardContent = speech_output
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response_robo(
        card_title, cardContent,speech_output, reprompt_text, should_end_session,endpointId,"startdance"))
        

    
        

def startIntent(intent,session,typeOfAction):
    endpointId = session["attributes"]["endpointId"]
    if session["attributes"]["spins"] == 0:
        output = "Alright, Let's see who is the lucky one. Keep your fingers crossed. <audio src='https://dagarbucket001.s3.amazonaws.com/IGarageFoleyRobotSpin10secone.mp3'/>"
        typeOfAction = "rotate"
    else:
        output = "Okay, Let's start the next round. <audio src='https://dagarbucket001.s3.amazonaws.com/IGarageFoleyRobotSpin15secone.mp3'/>"
        typeOfAction = "rotatetwo"
    title = "Welcome"
    cardContent = output
    reprompt_text = output
    should_end_session = False
    session_attributes = {
        "currentState" : "numberOfPlayers",
        "endpointId":endpointId,
        "spins":session["attributes"]["spins"] + 1
    }
    print("Type of Action", typeOfAction)
    return build_response(session_attributes, build_speechlet_response_robo(
        title, cardContent, output, reprompt_text, should_end_session,endpointId,typeOfAction))


def numberOfPlayers(intent,session):
    try:
        players = intent['slots']['players']['value']
    except:
        players == "X"
    try:
        currentState = session["attributes"]["currentState"]
    except :
        currentState == "XX"
    if players == "X" or currentState == "XX":
        return fallback(intent,session)
    elif currentState == "welcome":    
        output = "Okay, Let's start the " + str(players) + " player game. You may decide to sit in a circle. Place the robot in the middle. When ready, ask Alexa, spin. <audio src='https://dagarbucket001.s3.amazonaws.com/IwaitingCircleTone.mp3'/> "
    else:
        output = "Pardon. Say spin to spin the robot."
    title = "Welcome"
    cardContent = output
    reprompt_text = "You can ask Alexa to spin whenever you're ready."
    should_end_session = False
    session_attributes = {
        "currentState" : "numberOfPlayers",
        "endpointId":session["attributes"]["endpointId"],
        "spins":session["attributes"]["spins"]
    }
    return build_response(session_attributes, build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))

def choiceIntent(intent,session,typeOfAction):
    endpointId = session["attributes"]["endpointId"]
    choice = intent['slots']['choice']['value']
    if choice.lower() == "truth":
        output = "You chose " + choice + ". Okay then, here it goes. Did you ever skip school to go watch a movie?"
    elif choice.lower() == "dare":
        output = "You chose " + choice + ". Alright, I dare you to go outside of house, then cluck like a chicken as loudly as you can. <audio src='soundbank://soundlibrary/animals/amzn_sfx_rooster_crow_01'/>"
    else:
        output = "Sorry that is not a valid choice. Choose again Truth or Dare."
    title = "Welcome"
    cardContent = output
    reprompt_text = output
    should_end_session = False
    session_attributes = {
        "currentState" : "numberOfPlayers",
        "endpointId":session["attributes"]["endpointId"],
        "choice":choice,
        "spins": session["attributes"]["spins"]
    }
    return build_response(session_attributes, build_speechlet_response_robo(
        title, cardContent, output, reprompt_text, should_end_session,endpointId,typeOfAction))



def nextMove(intent,session,typeOfAction):
    endpointId = session["attributes"]["endpointId"]
    choice = session["attributes"]["choice"]
    if choice.lower() == "truth":
        output = "Well. Talk about being the cool one in the school.<audio src='soundbank://soundlibrary/human/amzn_sfx_crowd_excited_cheer_01'/> Alright then, say spin whenever you are ready."
    elif choice.lower() == "dare":
        output = " <audio src='soundbank://soundlibrary/human/amzn_sfx_crowd_excited_cheer_01'/> <audio src='soundbank://soundlibrary/animals/amzn_sfx_rooster_crow_02' /> You are quite the troublemaker! The game is just getting started. <audio src='soundbank://soundlibrary/animals/amzn_sfx_chicken_cluck_01'/> Whenever you're ready, say spin to spin the robot."
    title = "Playing"
    cardContent = output
    reprompt_text = output
    should_end_session = False
    session_attributes = {
        "currentState":"Playing",
        "endpointId":session["attributes"]["endpointId"],
        "choice":session["attributes"]["choice"],
        "spins":session["attributes"]["spins"]
    }
    return build_response(session_attributes, build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))



def fallback(intent,session):
    session_attributes = session["attributes"]
    output = "Sorry, Please repeat that."
    title = "Fallback"
    cardContent = output
    reprompt_text = output
    should_end_session = False
    return build_response(session_attributes,build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))
    

def receivedEventFromGadget(session,event):
    print("Event")
    print(event)
    session_attributes = session["attributes"]
    title = "Thank you"
    output = """
	Statue. <break time="5s"/>  Did you just smile? <break time="2s"/> hah! , <say-as interpret-as="interjection">Gotcha</say-as> <audio src="soundbank://soundlibrary/human/amzn_sfx_crowd_cheer_med_01"/> That was fun. Ready for another round?
			""".strip() 
    reprompt_text = output
    should_end_session = False
    cardContent = output
    return build_response(session_attributes,build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))
    


def on_session_started(session_started_request, session):
    """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])
         


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.

    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here
    return cancel_response(session_ended_request,session)


def on_launch(launch_request, session,event):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response(session,event)


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "AMAZON.HelpIntent":
        return help_response(session)
    elif intent_name == "AMAZON.CancelIntent":
	    return cancel_response(intent,session)
    elif intent_name == "AMAZON.StopIntent":
        return cancel_response(intent,session)
    elif intent_name == "rulesIntent":
        return rulesIntent(intent,session)
    elif intent_name == "startIntent":
        return startIntent(intent,session,"rotate")
    elif intent_name == "" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    elif intent_name == "AMAZON.FallbackIntent":
        return fallback(intent,session)
    elif intent_name == "AMAZON.YesIntent":
        return yesIntent(intent,session)
    elif intent_name == "AMAZON.NoIntent":
        return noIntent(intent,session)
    else:
        raise ValueError("Invalid intent")



def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")
    print(event['request']['type'])
    print(event['context'])
    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])

    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'],event)
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])
    elif event['request']['type'] == "CustomInterfaceController.EventsReceived":
        return receivedEventFromGadget(event['session'],event["request"]["events"][0])
