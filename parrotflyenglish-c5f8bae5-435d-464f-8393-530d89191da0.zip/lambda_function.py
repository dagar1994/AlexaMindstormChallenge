# -*- coding: utf-8 -*-
from __future__ import print_function
import random
from datetime import datetime
import json
import requests

options = ["Sparrow", "Crow", "Cuckoo", "Pigeon", "Mynah", "Parrot", "Horse", "Goat", "Frog", "Dog", "Duck", "Eagle", "Nightingale", "Bear", "Butterfly", "Vulture"]

sortedOptions = {"Fly":["Sparrow", "Crow", "Cuckoo", "Pigeon", "Mynah", "Parrot","Eagle", "Nightingale", "Butterfly", "Vulture"], "No":[ "Horse", "Goat", "Frog", "Dog", "Duck", "Bear"]}

def build_speechlet_response_start_listener(title, cardContent,output, reprompt_text, should_end_session,endpointId,typeOfAction):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + " <audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_waiting_loop_30s_01'/> <audio src='soundbank://soundlibrary/backgrounds_ambience/traffic/traffic_06'/> </speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        "directives": [
            {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 6000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND_AND_TERMINATE"  
                }
            },
            {
                "type": "CustomInterfaceController.SendDirective",
                "endpoint": {
                  "endpointId": endpointId
                },
                "header": {
                  "namespace": "Custom.Mindstorms.Gadget",
                  "name": "Control"
                },
                "payload": { 
                  "direction": "clockwise",
                  "times": 5,
                  "type" : typeOfAction,
                  "command" : "sentry"
                }
              }
        ],
        'shouldEndSession': should_end_session
    }



def build_speechlet_response_normal(title, cardContent,output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + "  </speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }





def build_speechlet_response_robo(title,cardContent , output, reprompt_text, should_end_session,endpointId,typeOfAction):
    return { 
        
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + " <audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_waiting_loop_30s_01'/>   </speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'directives': [
            {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 6000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND_AND_TERMINATE"  
                }
            },
            {
                "type": "CustomInterfaceController.SendDirective",
                "endpoint": {
                  "endpointId": endpointId
                },
                "header": {
                  "namespace": "Custom.Mindstorms.Gadget",
                  "name": "Control"
                },
                "payload": { 
                  "direction": "clockwise",
                  "times": 5,
                  "type" : typeOfAction,
                  "command" : "sentry"
                }
              }
            ],
        'shouldEndSession': should_end_session
    }


def build_speechlet_response(title, cardContent, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak> <audio src='soundbank://soundlibrary/animals/amzn_sfx_bird_forest_02'/> <audio src='soundbank://soundlibrary/animals/amzn_sfx_bird_forest_01'/>" + output + "</speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': "<speak>" + reprompt_text + "</speak>"
            }
        },
        'shouldEndSession': should_end_session
    }

def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


#----------------------------------------------------------------------------------------------

def checkGadgetConnectivity(apiEndpoint,accessToken):
    headers = {
    'Authorization': 'Bearer ' + accessToken,
    'Content-Type': 'application/json',
        }
    
    response = requests.get(apiEndpoint + '/v1/endpoints', headers=headers, verify=False)
    print(response)
    print(response.text)
    respJson = json.loads(response.text)
    try:
        endpointId = respJson["endpoints"][0]["endpointId"]
    except:
        endpointId = "X"
    return endpointId


def get_welcome_response(session,event):
    apiEndpoint = event["context"]["System"]["apiEndpoint"]
    accessToken = event["context"]["System"]["apiAccessToken"]
    endpointId = checkGadgetConnectivity(apiEndpoint,accessToken)
    
    if endpointId == "X":
        output = "Welcome to birds fly. Your gadget is not connected right now."
        title = "Welcome"
        cardContent = output
        reprompt_text = output
        should_end_session = False
        session_attributes = {}
    else:    
        output = "Welcome to Does it fly? Keep the robot in front of you, and keep your hand near the touch button.<break time='0.5s'/> I will start by saying name of a animal or bird, and if you think it can fly, you have to press the button. Else don't press the button.<break time='0.5s'/> You have only 3 seconds to decide. Say start whenever you are ready."
        title = "Welcome"
        cardContent = output
        reprompt_text = " " #"आप कितने लोग खेलना चाहेंगे?"
        should_end_session = False
        session_attributes = {
            "currentState" : "welcome",
            "endpointId":endpointId
        }
    return build_response(session_attributes, build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))
        
        
def cancel_response(intent,session):
    session_attributes = {}
    card_title = "Thank you"
    speech_output = """
	Thank you for playing birds fly. Come back again for more fun.
			""".strip() 
    reprompt_text = speech_output
    cardContent = speech_output
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, cardContent,speech_output, reprompt_text, should_end_session))


def noIntent():
    title = "Birds Fly"
    cardContent = title
    output = "Alright. It was fun playing with you. See you soon."
    reprompt_text = output
    should_end_session = True
    return build_response({},build_speechlet_response_normal(
        title, cardContent,output, reprompt_text, should_end_session))



def gameEnd(correct,wrong,endSound):
    title = "Chidiya udd"
    cardContent = title
    output = endSound +  " The game ends here. You answered " + str(correct) + " correct answers out of 5 . Would you like to play again ?"
    reprompt_text = output
    should_end_session = False
    return build_response({},build_speechlet_response_normal(
        title, cardContent,output, reprompt_text, should_end_session))



def receivedEventFromGadget(session,event):
    endpointId = session["attributes"]["endpointId"]
    currentChoice = session["attributes"]["currentChoice"]
    runningOptions = session["attributes"]["runningOptions"]
    question = session["attributes"]["question"]
    correct = session["attributes"]["correct"]
    wrong = session["attributes"]["wrong"]
    runningOptions.remove(currentChoice)
    print("Current Choice R")
    print(currentChoice)
    
    question = question + 1
    card_title = "Birds Fly"
    new = random.choice(runningOptions)
    if currentChoice in sortedOptions["Fly"]:
        print("Received Event from Gadget 1")
        speech_output = '<audio src="soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_positive_response_01"/>' + new + " fly."
        typeOfAction = "movefinger"
        correct = correct + 1
        endSound = '<audio src="soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_positive_response_01"/>'
    else:
        print("Received Event from Gadget 2")
        speech_output = "<audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_negative_response_01'/>"  + new + " fly." 
        typeOfAction = "movefingeragain"
        wrong = wrong + 1
        endSound = "<audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_negative_response_01'/>"
            	
    if question == 6:
        return gameEnd(correct,wrong,endSound)
    
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    reprompt_text = speech_output
    cardContent = speech_output
    
    session_attributes = {
        "currentState" : "numberOfPlayers",
        "endpointId":endpointId,
        "runningOptions": runningOptions,
        "currentChoice": new,
        "question" : question,
        "correct" : correct,
        "wrong" : wrong
    }
    print(session_attributes)
    
    return build_response(session_attributes, build_speechlet_response_start_listener(
        card_title,cardContent, speech_output, reprompt_text, should_end_session, endpointId,typeOfAction))

      
def listenerExpired(session):
    print("Session", session)
    endpointId = session["attributes"]["endpointId"]
    currentChoice = session["attributes"]["currentChoice"]
    runningOptions = session["attributes"]["runningOptions"]
    question = session["attributes"]["question"]
    correct = session["attributes"]["correct"]
    wrong = session["attributes"]["wrong"]
    runningOptions.remove(currentChoice)
    question = question + 1
    
    print("Current Choice E")
    print(currentChoice)
    card_title = "Birds Fly"
    new = random.choice(runningOptions)
    if currentChoice in sortedOptions["No"]:
        print("Listener expired 1")
        speech_output = '<audio src="soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_positive_response_01"/>' +  new + " fly."
        typeOfAction = "movefinger"
        correct = correct + 1
        endSound = '<audio src="soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_positive_response_01"/>'

    else:
        print("Listener expired 2")
        speech_output = "<audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_negative_response_01'/>" + new + " fly."
            	#बहुत बढ़िया .
            	#		""".strip() + 
        typeOfAction = "movefingeragain"
        wrong = wrong + 1
        endSound = "<audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_negative_response_01'/>"

    
    if question == 6:
        return gameEnd(correct,wrong,endSound)
    
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    reprompt_text = speech_output
    cardContent = speech_output
    session_attributes = {
        "currentState" : "numberOfPlayers",
        "endpointId":endpointId,
        "runningOptions": runningOptions,
        "currentChoice": new,
        "question" : question,
        "correct" : correct,
        "wrong" : wrong
    }
    
    print(session_attributes)
    return build_response(session_attributes, build_speechlet_response_start_listener(
        card_title,cardContent, speech_output, reprompt_text, should_end_session, endpointId,typeOfAction))


def startIntent(intent,session,typeOfAction):
    endpointId = session["attributes"]["endpointId"]
    a = random.choice(options)
    b = options.index(a)
    output = "<break time='0.5s'/> "+ a +  " fly."
    title = "Here starts the game."
    #runningOptions = options.pop(b)
    runningOptions = []
    print("Running Options", options)
    print(runningOptions)
    cardContent = output
    reprompt_text = " Let's start . "+ a +  " fly."
    should_end_session = False
    session_attributes = {
        "currentState" : "numberOfPlayers",
        "endpointId":endpointId,
        "runningOptions": options,
        "currentChoice": a,
        "question" : 1,
        "correct" : 0,
        "wrong" : 0
    }
    return build_response(session_attributes, build_speechlet_response_robo(
        title, cardContent, output, reprompt_text, should_end_session,endpointId,typeOfAction))


# def numberOfPlayers(intent,session):
#     try:
#         players = intent['slots']['players']['value']
#     except:
#         players == "X"
#     try:
#         currentState = session["attributes"]["currentState"]
#     except :
#         currentState == "XX"
#     if players == "X" or currentState == "XX":
#         return fallback(intent,session)
#     elif currentState == "welcome":    
#         output = "Okay, Let's start the " + str(players) + " player game. You may decide to sit in a circle. Place the robot in the middle. When ready, ask Alexa, spin. <audio src='https://dagarbucket001.s3.amazonaws.com/IwaitingCircleTone.mp3'/> "
#     else:
#         output = "Pardon. Say spin to spin the robot."
#     title = "Welcome"
#     cardContent = output
#     reprompt_text = "You can ask Alexa to spin whenever you're ready."
#     should_end_session = False
#     session_attributes = {
#         "currentState" : "numberOfPlayers",
#         "endpointId":session["attributes"]["endpointId"]
#     }
#     return build_response(session_attributes, build_speechlet_response(
#         title, cardContent, output, reprompt_text, should_end_session))

# def choiceIntent(intent,session,typeOfAction):
#     endpointId = session["attributes"]["endpointId"]
#     choice = intent['slots']['choice']['value']
#     if choice.lower() == "truth":
#         output = "You chose " + choice + ". Okay then, here it goes. Did you ever skip school to go watch a movie?"
#     elif choice.lower() == "dare":
#         output = "You chose " + choice + ". Alright, I dare you to go outside of house, then cluck like a chicken as loudly as you can."
#     else:
#         output = "Sorry that is not a valid choice. Choose again Truth or Dare."
#     title = "Welcome"
#     cardContent = output
#     reprompt_text = output
#     should_end_session = False
#     session_attributes = {
#         "currentState" : "numberOfPlayers",
#         "endpointId":session["attributes"]["endpointId"],
#         "choice":choice
#     }
#     return build_response(session_attributes, build_speechlet_response_robo(
#         title, cardContent, output, reprompt_text, should_end_session,endpointId,typeOfAction))



# def nextMove(intent,session,typeOfAction):
#     endpointId = session["attributes"]["endpointId"]
#     choice = session["attributes"]["choice"]
#     if choice.lower() == "truth":
#         output = "Well. Talk about being the cool one in the school.<break time='2.5s'/> Alright then, say spin whenever you are ready."
#     elif choice.lower() == "dare":
#         output = "cock a doodle doo. You are quite the troublemaker! The game is just getting started <break time='2.5s'/>. Whenever you're ready, say spin to spin the robot."
#     title = "Playing"
#     cardContent = output
#     reprompt_text = output
#     should_end_session = False
#     session_attributes = {
#         "currentState":"Playing",
#         "endpointId":session["attributes"]["endpointId"],
#         "choice":session["attributes"]["choice"]
#     }
#     return build_response(session_attributes, build_speechlet_response_robo(
#         title, cardContent, output, reprompt_text, should_end_session,endpointId,typeOfAction))



def fallback(intent,session):
    session_attributes = session["attributes"]
    output = "Sorry. I did not get that, please repeat."
    title = "Oops"
    cardContent = output
    reprompt_text = output
    should_end_session = False
    return build_response(session_attributes,build_speechlet_response(
        title, cardContent, output, reprompt_text, should_end_session))
    

# def receivedEventFromGadget(session,event):
#     print("Event Received from Gadget", event)
#     endpointId = session["attributes"]["endpointId"]
#     currentChoice = session["attributes"]["currentChoice"]
#     new = random.choice(session["attributes"]["runningOptions"])
#     #print("Event Received mein options", runningOptions)
#     print("Current Choice", currentChoice)
#     title = "Thank you"
#     if event["header"]["name"] == "completion":
#         if event["payload"]["flying"] == "completed":
#             output = "आप ने कुछ response नहीं दिया . दोबारा शुरू करते हैं ." + new + " उड़ . "
#         elif event["payload"]["flying"] == "made":
#             print("Choice Made")
#             print(sortedOptions["Fly"].values())
#             if currentChoice in sortedOptions["Fly"].values():
#                 output = """
#                  बहुत बढ़िया .
#             			""".strip() + new + " उड़ . "
#             else:
#                 output = "आप ने गलती कर दी. "
#     elif event["header"]["name"] == "buttonPress":
#         if event["payload"]["pressed"] == "pressedNow":
#             print("Choice Made")
#             print(sortedOptions["Fly"])
#             print(currentChoice in sortedOptions["Fly"])
#             if currentChoice in sortedOptions["Fly"]:
#                 print("In button press 1")
#                 output = new + " उड़ . "
#                 #"""
#             	#बहुत बढ़िया .
#             			#""".strip() + new + " उड़ . "
#             else:
#                 print("In button press 2")
#                 output = new + " उड़ . "

#         # else:
#         #     new = random.choice(session["attributes"]["runningOptions"])
#         #     output = "आप ने कुछ response नहीं दिया . दोबारा शुरू करते हैं . " + new + " उड़ ."
#     reprompt_text = output
#     should_end_session = False
#     cardContent = output
#     session_attributes = {
#         "currentState" : "receivedEvent",
#         "endpointId":endpointId,
#         "runningOptions": session["attributes"]["runningOptions"],
#         "currentChoice": new
#     }
#     return build_response(session_attributes,build_speechlet_response(
#         title, cardContent, output, reprompt_text, should_end_session))
    


def on_session_started(session_started_request, session):
    """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])
         


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.

    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here
    return cancel_response(session_ended_request,session)


def on_launch(launch_request, session,event):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response(session,event)


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "AMAZON.HelpIntent":
        return help_response(session)
    elif intent_name == "AMAZON.CancelIntent":
	    return cancel_response(intent,session)
    elif intent_name == "AMAZON.StopIntent":
        return cancel_response(intent,session)
    # elif intent_name == "numberOfPlayers":
    #     return numberOfPlayers(intent,session)
    elif intent_name == "startGame":
        return startIntent(intent,session,"movefingerfirst")
    elif intent_name == "choiceIntent":
        return choiceIntent(intent,session,"chill")
    elif intent_name == "doneIntent":
        return nextMove(intent,session,"rotatetwo")
    elif intent_name == "" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    elif intent_name == "AMAZON.FallbackIntent":
        return fallback(intent,session)
    elif intent_name == "AMAZON.NoIntent":
        return noIntent()
    else:
        raise ValueError("Invalid intent")



def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")
    print("In lambda handler", event['request']['type'])
    print("In lambda handler two", event['context'])
    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])

    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'],event)
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])
    elif event['request']['type'] == "CustomInterfaceController.Expired":
        return listenerExpired(event['session'])
    elif event['request']['type'] == "CustomInterfaceController.EventsReceived":
        return receivedEventFromGadget(event['session'],event["request"]["events"][0])

